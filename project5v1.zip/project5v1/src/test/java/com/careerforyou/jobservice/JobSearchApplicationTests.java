package com.careerforyou.jobservice;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class JobSearchApplicationTests {

	@Test
	void contextLoads() {
	}

}
